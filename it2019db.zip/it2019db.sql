-- --------------------------------------------------------
-- Hôte :                        localhost
-- Version du serveur:           10.1.37-MariaDB - mariadb.org binary distribution
-- SE du serveur:                Win32
-- HeidiSQL Version:             9.5.0.5332
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Listage de la structure de la table it2019. contact
CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `np` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `passe` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Listage des données de la table it2019.contact : ~8 rows (environ)
DELETE FROM `contact`;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` (`id`, `np`, `email`, `passe`) VALUES
	(1, 'nacer ali', 'na@gmail.com', 'nacer1234'),
	(2, 'bifidane alaa', 'ba@gmail.com', 'test1234'),
	(3, 'claude', 'claude@gmail.com', 'claudebernard'),
	(4, 'abir berkane', 'barkane@gmail.com', 'abir1234'),
	(5, 'abir berkane', 'barkane@gmail.com', 'abir1234'),
	(6, 'abir berkane', 'barkane@gmail.com', 'abir1234'),
	(7, 'abir berkane', 'barkane@gmail.com', 'abir1234'),
	(8, 'mayata', 'maya@gmail.com', 'maya');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;

-- Listage de la structure de la table it2019. produit
CREATE TABLE IF NOT EXISTS `produit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` text,
  `prix` float DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Listage des données de la table it2019.produit : ~3 rows (environ)
DELETE FROM `produit`;
/*!40000 ALTER TABLE `produit` DISABLE KEYS */;
INSERT INTO `produit` (`id`, `libelle`, `prix`, `quantite`) VALUES
	(13, 'dell ', 2000, 100),
	(14, 'noh noh', 9, 100),
	(15, 'coeur de neige', 20, 100);
/*!40000 ALTER TABLE `produit` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
